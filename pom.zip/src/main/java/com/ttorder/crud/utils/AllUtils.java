
package com.ttorder.crud.utils;

import java.util.List;

import com.alibaba.fastjson.JSONObject;

/** 
* @author 	yushuang
* @version 	2019年9月11日  下午4:22:05 
*  
*/

public class AllUtils {
	//将字符串转换为Integer
	public static Integer toIneger(String str) {
		return Integer.valueOf(str);
	}
	
	//将json字符串转换为对象单个
	public static <T> T allList(String json, Class<T> value){
		String req = "[" + json + "]";
		return JSONObject.parseArray(req, value).get(0);
	}
	//将json字符串转换为List
	public static <T> List<T> allList2(String json, Class<T> value){
		
		return  JSONObject.parseArray(json, value);
	}
}
