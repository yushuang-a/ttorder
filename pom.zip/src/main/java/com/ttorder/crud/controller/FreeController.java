
package com.ttorder.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ttorder.crud.bean.FreeInformation;
import com.ttorder.crud.service.FreeInformationService;
import com.ttorder.crud.utils.AllUtils;

/** 
* @author 	yushuang
* @version 	2019年8月30日  下午1:57:09 
*  
*/
@Controller
public class FreeController {

	@Autowired
	private FreeInformationService freeInformationService;
	
	//添加免费套餐
	@RequestMapping("/addfreepackage")
	@ResponseBody
	public String addfreepackage(@RequestParam("freeInformation") String freeInformation) {
		
		System.out.println(freeInformation);
		List<FreeInformation> freeInfo = AllUtils.allList2(freeInformation, FreeInformation.class);
		System.out.println(freeInfo.toString());
		for (FreeInformation free : freeInfo) {
			System.out.println(free);
			freeInformationService.addfree(free);
		}
		
		return "success";
	}
	//修改免费套餐
	@RequestMapping("/updatefreepackage")
	@ResponseBody
	public String updatefreepackage(@RequestParam("freeInformation") String freeInformation) {
		
		FreeInformation freeInfo = AllUtils.allList(freeInformation, FreeInformation.class);
		
		freeInformationService.updatefree(freeInfo);
		
		return "success";
	}
	
	//删除免费套餐
	@RequestMapping("/deletefreepackage")
	@ResponseBody
	public String deletefreepackage(@RequestParam("freeId") Integer freeId) {
		
		freeInformationService.deletefree(freeId);
		
		return "success";
	}
	
	//查询免费套餐
	@RequestMapping(value = "/selectfreepackage",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectfreepackage(@RequestParam(value ="pn",defaultValue = "1") Integer pn ) {
		PageHelper.startPage(pn, 5);//分页查询
		List<FreeInformation> list = freeInformationService.selectfree();
		PageInfo page = new PageInfo(list);
		return JSON.toJSONString(page);
	}

}
