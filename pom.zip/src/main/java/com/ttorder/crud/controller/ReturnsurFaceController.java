
package com.ttorder.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ttorder.crud.bean.OrderStats;
import com.ttorder.crud.bean.ReturnsurFaceInformation;
import com.ttorder.crud.service.OrderInformationService;
import com.ttorder.crud.service.ReturnsurFaceInformationService;
import com.ttorder.crud.utils.AllUtils;

/** 
* @author 	yushuang
* @version 	2019年8月9日  下午4:59:29 
*  
*/
@Controller
public class ReturnsurFaceController {

	
	
	@Autowired
	private ReturnsurFaceInformationService returnsurFaceInformationService;
	@Autowired
	private OrderInformationService orderInformationService;
	
	//添加回访单
	@RequestMapping("/addreturn")
	@ResponseBody
	public void addReturn(@RequestParam String returnsurFace) {
		
		ReturnsurFaceInformation returnsurFaceInformation = AllUtils.allList(returnsurFace, ReturnsurFaceInformation.class);
		
		if(returnsurFaceInformation.getCustomerLv().equals("5")) {
			
			String orderNo = returnsurFaceInformation.getOrderNo();
			Integer orderStatus = OrderStats.CLOSE.getValue();
			orderInformationService.updateOrderStats(orderNo,orderStatus);
			returnsurFaceInformationService.addReturnsurFaceInformation(returnsurFaceInformation);
		}else {
			returnsurFaceInformationService.addReturnsurFaceInformation(returnsurFaceInformation);
		
		}
	}
	//查看回访单
	
	@RequestMapping("/selectreturn")
	@ResponseBody
	public String selectReturn(@RequestParam String orderNo) {

		List<ReturnsurFaceInformation> list = returnsurFaceInformationService.selectReturnByOrderNo(orderNo);
		return JSON.toJSONString(list); 
		
	}

}
