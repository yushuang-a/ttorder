
package com.ttorder.crud.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ttorder.crud.bean.OrderInformation;
import com.ttorder.crud.bean.SupplierInformation;
import com.ttorder.crud.service.SupplierInformationService;
import com.ttorder.crud.utils.AllUtils;

/** 
* @author 	yushuang
* @version 	2019年7月24日  时间5:54:47 
*  
*/
@Controller
public class SupplierController {

	
	@Autowired
	SupplierInformationService supplierInformationService;
	//添加经销商
	@RequestMapping(value = "/addDis",produces = "application/json; charset=utf-8")
	@ResponseBody
	public void addDistributorController(@RequestParam("supplierInformation") String supplierInformation) {

		SupplierInformation supplier = AllUtils.allList(supplierInformation,SupplierInformation.class);
		
		
		supplierInformationService.addCompany(supplier);
	}
	
	//查询所有经销商分页
	@RequestMapping(value = "/selectdis",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectDis(@RequestParam(value = "pn",defaultValue ="1") int pn) {
		
		
		//分页查询
		PageHelper.startPage(pn, 10);
		List<SupplierInformation> spittles = supplierInformationService.selectCompany();

		PageInfo page = new PageInfo(spittles);
		return JSON.toJSONString(page);
	}
	
	//查询经销商不分页
	@RequestMapping(value = "/selectDisnopage",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectDisnopage() {
		
		
		
		List<SupplierInformation> spittles = supplierInformationService.selectCompany();

		return JSON.toJSONString(spittles); 
	}
	//修改经销商信息
	@RequestMapping(value = "/updateDis")
	@ResponseBody
	public void updateDis(@RequestParam("supplierInformation") String sup) {
		
		SupplierInformation supplier = AllUtils.allList(sup,SupplierInformation.class);
	
		supplierInformationService.updateCompany(supplier);

	}
	//删除经销商信息
	@RequestMapping(value = "/deleteDis")
	@ResponseBody
	public void deleteDis(@RequestParam("supplierId") String supId) {
		
		int supplierId = Integer.valueOf(supId).intValue();
		
		supplierInformationService.deleteCompany(supplierId);

	}
	
	//根据公司类别搜索公司
	@RequestMapping(value = "/searchDis",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String searchDis(@RequestParam("businessClass") String businessClass) {

		List<SupplierInformation> list = supplierInformationService.searchBytype(businessClass);
		
		return JSON.toJSONString(list);
	}
		
}
