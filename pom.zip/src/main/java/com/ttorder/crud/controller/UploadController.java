
package com.ttorder.crud.controller;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ttorder.crud.bean.ImgInformation;
import com.ttorder.crud.service.ImgService;

/** 
* @author 	yushuang
* @version 	2019年8月24日  下午4:15:45 
*  
*/
@Controller
public class UploadController {

	
		@Autowired
		private ImgService imgService;
		
		
		@RequestMapping(value = "/uploadimg")
		public String addImg(HttpServletRequest request ,
				@RequestParam("idCode") String idCode,
				@RequestParam("file") MultipartFile pictureFile) throws Exception{
			
			
			ImgInformation imgInformation = new ImgInformation();
			imgInformation.setIdCode(idCode);
			System.out.println(imgInformation.getIdCode());
			System.out.println(pictureFile);
			
				//使用UUID给图片重命名，并去掉四个“-”
				String name = pictureFile.getName();
				
				//获取文件的扩展名
				String ext = FilenameUtils.getExtension(pictureFile.getOriginalFilename());
				//设置图片上传路径
				String url = request.getSession().getServletContext().getRealPath("/upload");
				String fileUrl = "/" + name +(new Date()).toString();
				
				File file=new File(url + fileUrl);
				if(!file.exists()){//如果文件夹不存在
					file.mkdir();//创建文件夹
				}
				//以绝对路径保存重名命后的图片
				pictureFile.transferTo(new File(url + fileUrl+"/"+name + "." + ext));
				//把图片存储路径保存到数据库
				imgInformation.setImageurl("upload/"+ fileUrl + name + "." + ext);
				
				imgService.addImg(imgInformation);
			
			
			//重定向到查询所有用户的Controller，测试图片回显
			return "userList";
			
		}
		
		
		@RequestMapping(value = "/getImg",produces = "application/json; charset=utf-8")
		@ResponseBody
		public String getImg(String idcode) throws Exception{
			
			List<ImgInformation> imgList = imgService.getAllImg(idcode);
			return JSON.toJSONString(imgList);
		}
	
}