
package com.ttorder.crud.controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.ttorder.crud.bean.EmployeeInformation;
import com.ttorder.crud.service.ActionService;

/** 
* @author 	yushuang
* @version 	2019年7月25日  上午9:19:44 
*  
*/
@Controller
public class ActionController {
	
	
	@Autowired
	private ActionService actionService;
	@RequestMapping(value = "/login",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String loginController(HttpServletRequest hq,
			HttpServletResponse hp,
			@RequestParam String telephone,
			@RequestParam String password) {
		
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		
		HttpSession session = hq.getSession();
		
		
		try {
		if(telephone != null) {
			
			EmployeeInformation employeeInformation = actionService.loginInfo(telephone);
			if(password.equals(employeeInformation.getPassword())) {
				
				session.setAttribute("telephone", telephone);
				session.setAttribute("password", employeeInformation.getPassword());
				session.setAttribute("jurisdiction", employeeInformation.getJurisdiction());
				map.put("tureorfalse", "登陆成功，欢迎使用！");
				map.put("url","主页地址");
				map.put("userInfo",employeeInformation);	
			}else {
				map.put("tureorfalse","用户名或密码错误！请重新登陆或者联系管理员！");
				map.put("url","登陆地址");
				
			}
			
		}else {		
			map.put("tureorfalse","用户名或密码错误！请重新登陆或者联系管理员！");
			map.put("url","登陆地址");
		}
		}catch(Exception e) {
			
			map.put("exception", e);
		}
		return JSON.toJSONString(map);
	}
	
}
