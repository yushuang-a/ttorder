
package com.ttorder.crud.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ttorder.crud.bean.EmployeeInformation;
import com.ttorder.crud.bean.OrderInformation;
import com.ttorder.crud.bean.SupplierInformation;
import com.ttorder.crud.bean.WeChatUrlData;
import com.ttorder.crud.dao.OrderInformationMapper;
import com.ttorder.crud.service.EmployeeInformationService;
import com.ttorder.crud.service.OrderInformationService;
import com.ttorder.crud.service.SupplierInformationService;
import com.ttorder.crud.service.WeChatService;
import com.ttorder.crud.utils.AllUtils;
import com.ttorder.crud.utils.WeChatMsgSend;


/** 
* @author 	yushuang
* @version 	2019年9月17日  下午3:42:28 
*  
*/
@Controller
public class WeChatController {

	@Autowired
	private OrderInformationService orderInformationService;
	@Autowired
	private SupplierInformationService supplierInformationService;
	@Autowired
	private EmployeeInformationService employeeInformationService;
	@Autowired
	private WeChatService weChatService;
	@RequestMapping("/sendWeChat")
	@ResponseBody
	public String sendWeChatToUser(Integer empId,Integer orderId) {
		/*
		 * 传入参数：empId，和msg
		 */
		//根据id获取企微账号
		EmployeeInformation info = employeeInformationService.selectEmpById(empId);
		String toUser = info.getToUser();
		OrderInformation orderInfo = orderInformationService.getOrder(orderId);
		SupplierInformation  suppInfo = supplierInformationService.getSupp(AllUtils.toIneger(orderInfo.getDistributorName()));
		EmployeeInformation constantInfo =  employeeInformationService.selectEmpById(AllUtils.toIneger(orderInfo.getDistributorContactsName()));
		
		//组装信息
		String msg ="派单：" + orderInfo.getBrand() +"新单\r\n" + 
		  "安装服务编号：" + orderInfo.getOrderNo() + "\r\n" +
		  "经销商代码：" + suppInfo.getBusinessCode() + "\r\n" +
		 "经销商：" + suppInfo.getBusinessFullName() + "\r\n" +
		 "车型：" + orderInfo.getCarType() + "\r\n" +
		 "销售顾问：" + constantInfo.getEmployeeName() + "\t联系方式(手机):" + constantInfo.getTelephone() + "\r\n" +
		 "车架号：" + orderInfo.getCarNo() + "\r\n" +
		  "客户：" + orderInfo.getOwnerName() + "\t联系方式(手机):" + orderInfo.getOwnerNo() + "\r\n" +
		  "地址：" + orderInfo.getOwnerInsAddress() + "\r\n" +
		  "麻烦尽快联系客户勘测！";
		

	    weChatService.sendWeChat(toUser, msg);
	    
		return "success";
	}
}
