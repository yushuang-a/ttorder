
package com.ttorder.crud.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ttorder.crud.bean.CellInformation;
import com.ttorder.crud.service.CellInformationService;
import com.ttorder.crud.utils.AllUtils;

/** 
* @author 	yushuang
* @version 	2019年8月30日  下午2:24:06 
*  
*/
@Controller
public class CellController {

	private static final Logger logger = LogManager.getLogger(CellController.class);
	@Autowired
	private CellInformationService cellInformationService;
	//添加小区信息
	@RequestMapping("/addCell")
	@ResponseBody
	public String addCell(@RequestParam("cellInformation") String cellInformation) {
		
		CellInformation cellInfo = AllUtils.allList(cellInformation, CellInformation.class);
		try {
			cellInformationService.addCellInfo(cellInfo);
		} catch (Exception e) {
			logger.info(e);
		}
		
		return "success";
	}
	//修改小区信息
	@RequestMapping("/updateCell")
	@ResponseBody
	public String updateCell(@RequestParam("cellInformation") String cellInformation) {
		
		CellInformation cellInfo = AllUtils.allList(cellInformation, CellInformation.class);
		try {
			cellInformationService.updateCellInfo(cellInfo);
		} catch (Exception e) {
			logger.info(e);
		}
		return "success";
	}
	//根绝ID删除小区信息
	@RequestMapping("/deleteCell")
	@ResponseBody
	public String deleteCell(@RequestParam("cellId") Integer cellId) {
		try {
			cellInformationService.deleteCellInfo(cellId);
		} catch (Exception e) {
			logger.info(e);
		}
		return "success";
	}
	//查询所有小区信息
	
	@RequestMapping(value = "/selectCell",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectCell(@RequestParam(value ="pn",defaultValue = "1") Integer pn ) {

		PageHelper.startPage(pn, 5);//分页查询
		List<CellInformation> list = cellInformationService.selectCellInfo();
		PageInfo page = new PageInfo(list);
		return JSON.toJSONString(page);
	}
	//查询小区不分页
	@RequestMapping(value = "/selectCellNoPages",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectCellNoPages() {
		
		List<CellInformation> list = cellInformationService.selectCellInfo();
	
		return JSON.toJSONString(list);
	}
	//按类型模糊查询小区
	@RequestMapping(value = "/selectCellWith",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectCellWith(@RequestParam(value ="pn",defaultValue = "1") Integer pn ,
			@RequestParam("str") String str,
			@RequestParam("value") String value) {
		PageHelper.startPage(pn, 5);//分页查询	
		List<CellInformation> list = cellInformationService.selectByClass(str, value);
		PageInfo page = new PageInfo(list);
		return JSON.toJSONString(page);
	}
	
}
