
package com.ttorder.crud.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ttorder.crud.bean.QuotationInformation;
import com.ttorder.crud.service.QuotationInformationService;
import com.ttorder.crud.utils.AllUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/** 
* @author 	yushuang
* @version 	2019年8月19日  下午2:20:03 
*  
*/
@Controller
public class QuotationController {

    @Autowired
    private QuotationInformationService quotationInformationService;
    /*
    添加报价表
     */

    @RequestMapping(value = "/addquota")
    @ResponseBody
    public String addquota(String quotationInformation){

        QuotationInformation quota = AllUtils.allList(quotationInformation,QuotationInformation.class);

        quotationInformationService.addQuotation(quota);

        return null;
    }


    /*
    删除报价表
     */
    @RequestMapping(value = "/deletequota")
    @ResponseBody
    public String deletequota(Integer quotationSheetId){
    	
    	try {
	 quotationInformationService.deleteQuotation(quotationSheetId);
    	} catch (Exception e) {
    		return e.toString();
    	}      
        return "success";
    }

    /*
    根据物料ID查询标价表
     */

    @RequestMapping(value = "/selectAllquo",produces = "application/json; charset=utf-8")
    @ResponseBody
    public String selectAllquo(String materialScienceId){

        List<QuotationInformation> list = quotationInformationService.seleteAllquotation(materialScienceId);

        return JSON.toJSONString(list);
    }

}
