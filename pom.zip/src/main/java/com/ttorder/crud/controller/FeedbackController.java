
package com.ttorder.crud.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.ttorder.crud.bean.FeedbackInformation;
import com.ttorder.crud.service.FeedbackService;
import com.ttorder.crud.utils.AllUtils;

/** 
* @author 	yushuang
* @version 	2019年9月19日  上午11:13:38 
*  
*/
@Controller
@RequestMapping("/feedback")
public class FeedbackController {

	private static final Logger logger = LogManager.getLogger(FeedbackController.class);
	@Autowired
	private FeedbackService feedbackService;
	//添加
	@RequestMapping("/addfeed")
	@ResponseBody
	public String addFeedBack(String feedback) {
		
		FeedbackInformation info = AllUtils.allList(feedback, FeedbackInformation.class);
		try {
			feedbackService.creatFeed(info);
		} catch (Exception e) {
			logger.info(e);
		}
		
		
		return "success";
	}
	
	//删除
	@RequestMapping("/deletefeed")
	@ResponseBody
	public String deleteFeedBack(Integer id) {
		
		try {
			feedbackService.outFeed(id);
		} catch (Exception e) {
			logger.info(e);
		}
		
		
		return "success";
	}
	//查询
	@RequestMapping(value = "/sechfeed",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String sechFeedBack(String orderNo) {
			
			List<FeedbackInformation> list = feedbackService.searchFeed(orderNo);

			return JSON.toJSONString(list);
		}
}
