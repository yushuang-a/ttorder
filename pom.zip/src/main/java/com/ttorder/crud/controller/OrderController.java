
package com.ttorder.crud.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.mysql.jdbc.log.Log;
import com.ttorder.crud.bean.ConstructionInformation;
import com.ttorder.crud.bean.OrderDetailsInformation;
import com.ttorder.crud.bean.OrderInformation;
import com.ttorder.crud.bean.OrderStats;
import com.ttorder.crud.bean.QuotationInformation;
import com.ttorder.crud.bean.ReturnsurFaceInformation;
import com.ttorder.crud.service.ConstructionInformationService;
import com.ttorder.crud.service.OrderDetailsInformationService;
import com.ttorder.crud.service.OrderInformationService;
import com.ttorder.crud.service.QuotationInformationService;
import com.ttorder.crud.service.ReturnsurFaceInformationService;
import com.ttorder.crud.utils.AllUtils;
import com.ttorder.crud.utils.LogInterceptor;

/** 
* @author 	yushuang
* @version 	2019年7月23日  下午3:28:38 
*  订单的基本操作
*/

@Controller
public class OrderController {
	private static final Logger logger = LogManager.getLogger(OrderController.class);
	@Autowired
	private OrderInformationService orderInformationService;
	//保存添加订单基础信息，状态码设置为2
	@RequestMapping(value = "/addOrder")
	@ResponseBody
	public void addOrderController(@RequestParam("orderInformation") String res) {
		

		OrderInformation orderInformation = AllUtils.allList(res,OrderInformation.class);
		
		String orderNo = orderInformation.getOrderNo();
		
		orderInformation.setOrderStatus(OrderStats.IN_SURVEY.getValue());
		
		orderInformationService.addAll(orderInformation);
		
	}
	//提交订单，状态码设置为2
	@RequestMapping(value = "/subOrder")
	@ResponseBody
	public void subOrderController(@RequestParam OrderInformation orderInformation) {
		//获取订单ID，与数据库对比是否存在
		Integer orderId = orderInformation.getOrderId();
		orderInformation.setOrderStatus(OrderStats.IN_SURVEY.getValue());
		orderInformationService.addAll(orderInformation);
		
	}
	//修改订单信息
	//删除订单信息
	
	@Autowired
	private ConstructionInformationService constructionInformationService;
	//添加施工单
	@RequestMapping(value = "/addConstruction")
	@ResponseBody
	public void addConstructionController(
			@RequestParam("constructionInformation") String constructionInformation) {
		
		ConstructionInformation constructionInfo = AllUtils.allList(constructionInformation,ConstructionInformation.class);
		
		String orderNo = constructionInfo.getOrderNo();
		String constructionType = constructionInfo.getConstructionType();
		Integer orderStatus = 0;
		
		if(constructionType.equals("安装")) {
			orderStatus = OrderStats.INSTALLATION_AFTER.getValue();//修改为安装审核状态
		}else if(constructionType.equals("勘测")) {
			orderStatus = OrderStats.IN_SURVEY_AFTER.getValue();//修改为审核状态
		}
		//根据订单号修改状态码
		orderInformationService.updateOrderStats(orderNo,orderStatus);
		constructionInformationService.addConstructionOrder(constructionInfo);
		
	}
	
	
	
	//添加订单明细金额
	@Autowired
	private OrderDetailsInformationService orderDetailsInformationService;
	@RequestMapping(value = "/addQuotation")
	@ResponseBody
	public void addQuotation(@RequestParam("quotationInfo") String quotationInfor) {

		List<OrderDetailsInformation> list = AllUtils.allList2(quotationInfor, OrderDetailsInformation.class);
		for (OrderDetailsInformation orderDetailsInformation : list) {
			System.out.println(orderDetailsInformation);
			orderDetailsInformationService.addDetails(orderDetailsInformation);
		}

	}

	
	//根据施工单类型和订单号查询 ,施工单信息
	
	@RequestMapping(value = "/selectsheet",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectSheet(@RequestParam("orderNo")String orderNo,
			@RequestParam("constructionType")Integer type) {
		
		String constructionType = "";
		if(type == 1) {
			constructionType = "勘测";
		}else if(type == 2) {
			constructionType = "安装";
		}

		List<ConstructionInformation> list = constructionInformationService.selectByOrderNo(orderNo, constructionType);
		
		return JSON.toJSONString(list);
	}
	
	
	//根据状态码查询对应订单
	@RequestMapping(value="/selectAllOrder",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectAllOrder(
			@RequestParam("orderStatus") Integer orderStatus) {
		//将ID转化为名字
		
		List<OrderInformation> orders = orderInformationService.selectAll(orderStatus);
		
		return JSON.toJSONString(orders);
	}
	
	//待办事项查询 
	@RequestMapping(value = "/selectOrderByemp",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectOrderByemp(
			@RequestParam("empId") Integer empId,
			@RequestParam("department")Integer departmentType,
			@RequestParam(value = "pn",defaultValue ="1") Integer pn) {
		
	/**
	 * 1.  通过权限确定施工/客服（department）
	 * 2.如果是施工，通过部门确定是安装还是勘测  通过状态码查询在所有这个状态的订单，查出其中关于员工ID的订单
	 * 3.如果是客服状态码是查询所有
	 */
		PageHelper.startPage(pn, 5);//分页查询
		List<OrderInformation> list = orderInformationService.selectAllByemp(empId,departmentType);
		PageInfo page = new PageInfo(list);
		return JSON.toJSONString(page);
	}
	
	
	//订单备注修改
	
	
	
	//查询所有订单
	@RequestMapping(value = "/selectAllOrderWhithNull",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectAllOrderWhithNull(@RequestParam(value = "pn",defaultValue ="1") Integer pn) {
		
		PageHelper.startPage(pn, 5);//分页查询
		List<OrderInformation> list =orderInformationService.selectAllOrder();
		PageInfo page = new PageInfo(list);
		return JSON.toJSONString(page);
	}
	//模糊搜索订单
	@RequestMapping(value = "/selectAllOrderInfo",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectAllOrderInfo(
			@RequestParam(value = "pn",defaultValue ="1") Integer pn,
			@RequestParam("str") String str,
			@RequestParam("value") String value) {
		PageHelper.startPage(pn, 5);//分页查询
		
		List<OrderInformation> list = orderInformationService.selectAllInfo(str, value);
		
		PageInfo page = new PageInfo(list);
		return JSON.toJSONString(page);
	}
	//修改服务反馈
	@RequestMapping("updateremarks")
	@ResponseBody
	public String updateremakes(String orderNo,String newremakes) {
		
		System.out.println("订单号："+ orderNo + "服务反馈：" +newremakes);
		try {
			orderInformationService.updateremarksByorderNo(orderNo,newremakes);
		} catch (Exception e) {
			
			return e.toString();
		}
		
		return "success";
	}
	
	
	
	//从Session中获取用户名
	public static String getUsername(HttpServletRequest request) {
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("username");
		return username;		
	}

}
