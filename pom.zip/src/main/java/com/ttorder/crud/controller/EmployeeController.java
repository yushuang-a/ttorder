
package com.ttorder.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ttorder.crud.bean.EmployeeInformation;
import com.ttorder.crud.bean.OrderInformation;
import com.ttorder.crud.service.EmployeeInformationService;
import com.ttorder.crud.utils.AllUtils;

/** 
* @author 	yushuang
* @version 	2019年7月25日  下午4:05:40 
*  
*/
@Controller
public class EmployeeController {

	//添加人员
	@Autowired
	private EmployeeInformationService employeeInformationService;
	@RequestMapping(value = "/addEmp")
	@ResponseBody
	public void addEmpController(@RequestParam("emp") String emp) {
		
		EmployeeInformation employeeInformation = AllUtils.allList(emp,EmployeeInformation.class);
		
		employeeInformationService.addEmp(employeeInformation);
		
	}
	
	//修改人员信息	
	@RequestMapping(value = "/updateEmp")
	@ResponseBody
	public void updateEmpController(@RequestParam("emp") String emp) {
		
		
		EmployeeInformation employeeInformation = AllUtils.allList(emp,EmployeeInformation.class);
		
		employeeInformationService.updateEmp(employeeInformation);
		
	}
	
	//删除人员信息
	@RequestMapping(value = "/deleteEmp")
	@ResponseBody
	public void deleteEmpController(@RequestParam("employeeId") Integer employeeId) {
	
		employeeInformationService.deleteEmp(employeeId);
	}
	
	//查询所有人员信息，分页
	@RequestMapping(value = "/selectAllEmp",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectEmpController(@RequestParam(value = "pn",defaultValue ="1") int pn) {
		
		PageHelper.startPage(pn, 5);
		List<EmployeeInformation> list = employeeInformationService.selectEmp();
		PageInfo page = new PageInfo(list);
		return JSON.toJSONString(page);
		
	}
	
	//搜索人不分页
	@RequestMapping(value = "/selectEmp",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectEmp() {
		
		List<EmployeeInformation> list = employeeInformationService.selectEmp();
		return JSON.toJSONString(list);
		
	}
	
	//根据需要搜索人员列表
	@RequestMapping(value = "/searchEmpByType",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String searchEmpByType(@RequestParam("employeeClass") String employeeClass) {
		
		List<EmployeeInformation> list = employeeInformationService.searchEmp(employeeClass);
		
		return JSON.toJSONString(list);
	}
	
	//根据类型模糊搜索人员列表
	@RequestMapping(value = "/searchEmpByClass",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String searchEmpByClass(
			@RequestParam(value = "pn",defaultValue ="1") Integer pn,
			@RequestParam("str") String str,
			@RequestParam("value") String value) {
			PageHelper.startPage(pn, 10);//分页查询
			System.out.println(str+value);
			List<EmployeeInformation> list = employeeInformationService.selectAllInfo(str,value);
			PageInfo page = new PageInfo(list);
			return JSON.toJSONString(page);
		}
	
}
