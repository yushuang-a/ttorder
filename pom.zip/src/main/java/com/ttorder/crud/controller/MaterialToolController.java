
package com.ttorder.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ttorder.crud.bean.MaterialToolInformation;
import com.ttorder.crud.bean.OrderDetailsInformation;
import com.ttorder.crud.bean.OrderInformation;
import com.ttorder.crud.service.MaterialToolInformationService;
import com.ttorder.crud.service.OrderDetailsInformationService;
import com.ttorder.crud.utils.AllUtils;

/** 
* @author 	yushuang
* @version 	2019年8月5日  下午3:15:21 
*  
*/
@Controller
public class MaterialToolController {

	
	@Autowired
	private MaterialToolInformationService materialToolInformationService;
	@Autowired
	private OrderDetailsInformationService orderDetailsInformationService;
	
	//添加物料信息
	@RequestMapping("/addmt")
	@ResponseBody
	public void addMT(@RequestParam("mtinformation") String materialToolInformation) {
		
		MaterialToolInformation materialToolInfor = AllUtils.allList(materialToolInformation, MaterialToolInformation.class);
		
		materialToolInformationService.addMaterialTool(materialToolInfor);
		
	}
	//修改物料信息
	@RequestMapping("/updatemt")
	@ResponseBody
	public void updateMT(@RequestParam("mtInformation")String mtInformation) {
		
		MaterialToolInformation materialToolInfor = AllUtils.allList(mtInformation, MaterialToolInformation.class);
		
		materialToolInformationService.updateMaterialTool(materialToolInfor);
	}
	
	//根据物料ID删除物料信息
	@RequestMapping("/deletemt")
	@ResponseBody
	public void deleteMT(@RequestParam("materialId") Integer materialId) {
		
		materialToolInformationService.deleteMaterialTool(materialId);
	}
	
	//根据物料类型查询物料列表
	@RequestMapping(value = "/selectmt",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectMT(@RequestParam("materialClass") String materialClass,
			@RequestParam(value = "pn",defaultValue = "1") Integer pn) {
		
		PageHelper.startPage(pn, 5);//分页查询
		List<MaterialToolInformation> materialToolList = materialToolInformationService.selectMaterialTool(materialClass);
		PageInfo page = new PageInfo(materialToolList);
		
		return JSON.toJSONString(page);
	}
	//添加订单明细时查询所有物料报价分页
	@RequestMapping(value = "/selectmtque",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectMTWithQue(@RequestParam(value = "pn",defaultValue = "1") Integer pn) {
		
		PageHelper.startPage(pn, 6);//分页查询
		List<MaterialToolInformation> materialToolList = materialToolInformationService.selectAllWithQue();
		PageInfo page = new PageInfo(materialToolList);
		
		return JSON.toJSONString(page);
	}
	
	//根据施工单号查询订单明细列表
	@RequestMapping(value = "/select",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectOrderDetails(String constructionId) {
		List<OrderDetailsInformation> list = orderDetailsInformationService.selectOrderDetailsById(constructionId);
		return JSON.toJSONString(list);
	}
	//根据物料名搜索
	@RequestMapping(value = "/selectMTByName",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String selectMTByName(String mtname) {
		
		List<MaterialToolInformation> list = materialToolInformationService.selectMtByMtname(mtname);
		
		return JSON.toJSONString(list);
	}

}
