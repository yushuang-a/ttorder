
package com.ttorder.crud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ttorder.crud.bean.ConstructionInformation;
import com.ttorder.crud.bean.OrderInformation;
import com.ttorder.crud.bean.OrderStats;
import com.ttorder.crud.service.ConstructionInformationService;
import com.ttorder.crud.service.OrderInformationService;

/** 
* @author 	yushuang
* @version 	2019年8月14日  上午10:18:06 
*  
*/
@Controller
public class AllOrderController {

	@Autowired
	private OrderInformationService orderInformationService;
	@Autowired
	private ConstructionInformationService constructionInformationService;
	@RequestMapping(value = "/select/allOrder")
	@ResponseBody
	public String allOrder(@RequestParam String orderNo) {
		
		 OrderInformation orderInformation = orderInformationService.selectOrder(orderNo);

		return null;
	}
		//审核订单详情
		@RequestMapping("/checkOrder")
		@ResponseBody
		public String checkOrder(String orderNo,Integer type,Integer auditCode) {
			Integer orderStatus = 0;
			if(type == 2) {
				if(auditCode == 1) {
					orderStatus = OrderStats.IN_VISIT.getValue();//修改为回访中
				}else {
					orderStatus = OrderStats.INSTALLATION.getValue();//修改为安装中
				}
				
			}else if(type == 1) {
				if(auditCode == 1) {
					orderStatus = OrderStats.INSTALLATION.getValue();//修改为安装中
				}else {
					orderStatus = OrderStats.IN_SURVEY.getValue();//修改为勘测中
				}
			}
			try {
				orderInformationService.updateOrderStats(orderNo,orderStatus);
			} catch (Exception e) {
				return e.toString();
			}

			return "success";
		}

		//订单号，员工ID,修改安装人员
		@RequestMapping("/installer")
		@ResponseBody
		public String updateInstaller(String orderNo,Integer empId) {
			
			try {
				orderInformationService.addInstallerToOrder(orderNo,empId);
			} catch (Exception e) {
				return e.toString();
			}
			
			return "success";
		}
		
}
