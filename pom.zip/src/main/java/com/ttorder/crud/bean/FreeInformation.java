package com.ttorder.crud.bean;

public class FreeInformation {
    private Integer freeId;

    private String materialScienceId;

    private String materialScienceNo;

    private String freeRemarks;

    private String freeName;

    public Integer getFreeId() {
        return freeId;
    }

    public void setFreeId(Integer freeId) {
        this.freeId = freeId;
    }

    public String getMaterialScienceId() {
        return materialScienceId;
    }

    public void setMaterialScienceId(String materialScienceId) {
        this.materialScienceId = materialScienceId == null ? null : materialScienceId.trim();
    }

    public String getMaterialScienceNo() {
        return materialScienceNo;
    }

    public void setMaterialScienceNo(String materialScienceNo) {
        this.materialScienceNo = materialScienceNo == null ? null : materialScienceNo.trim();
    }

    public String getFreeRemarks() {
        return freeRemarks;
    }

    public void setFreeRemarks(String freeRemarks) {
        this.freeRemarks = freeRemarks == null ? null : freeRemarks.trim();
    }

    public String getFreeName() {
        return freeName;
    }

    public void setFreeName(String freeName) {
        this.freeName = freeName == null ? null : freeName.trim();
    }
}