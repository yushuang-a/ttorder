package com.ttorder.crud.bean;

import java.util.Date;

import com.alibaba.fastjson.annotation.JSONField;

public class ReturnsurFaceInformation {
    private Integer returnId;

    @JSONField (format="yyyy-MM-dd")
    private Date returnDate;

    private String visitors;

    private String visitorsNo;

    private String customerLv;

    private String customerFeedback;

    private String orderNo;

    public Integer getReturnId() {
        return returnId;
    }

    public void setReturnId(Integer returnId) {
        this.returnId = returnId;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    public String getVisitors() {
        return visitors;
    }

    public void setVisitors(String visitors) {
        this.visitors = visitors == null ? null : visitors.trim();
    }

    public String getVisitorsNo() {
        return visitorsNo;
    }

    public void setVisitorsNo(String visitorsNo) {
        this.visitorsNo = visitorsNo == null ? null : visitorsNo.trim();
    }

    public String getCustomerLv() {
        return customerLv;
    }

    public void setCustomerLv(String customerLv) {
        this.customerLv = customerLv == null ? null : customerLv.trim();
    }

    public String getCustomerFeedback() {
        return customerFeedback;
    }

    public void setCustomerFeedback(String customerFeedback) {
        this.customerFeedback = customerFeedback == null ? null : customerFeedback.trim();
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo == null ? null : orderNo.trim();
    }
}