package com.ttorder.crud.bean;

public class QuotationInformation {
    private Integer quotationSheetId;

    private String quotationClass;

    private String materialScienceId;

    private String serviceBrand;

    private Integer supplierId;

    private String quotedVersion;

    private String unitPrice;

    public Integer getQuotationSheetId() {
        return quotationSheetId;
    }

    public void setQuotationSheetId(Integer quotationSheetId) {
        this.quotationSheetId = quotationSheetId;
    }

    public String getQuotationClass() {
        return quotationClass;
    }

    public void setQuotationClass(String quotationClass) {
        this.quotationClass = quotationClass == null ? null : quotationClass.trim();
    }

    public String getMaterialScienceId() {
        return materialScienceId;
    }

    public void setMaterialScienceId(String materialScienceId) {
        this.materialScienceId = materialScienceId == null ? null : materialScienceId.trim();
    }

    public String getServiceBrand() {
        return serviceBrand;
    }

    public void setServiceBrand(String serviceBrand) {
        this.serviceBrand = serviceBrand == null ? null : serviceBrand.trim();
    }

    public Integer getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Integer supplierId) {
        this.supplierId = supplierId;
    }

    public String getQuotedVersion() {
        return quotedVersion;
    }

    public void setQuotedVersion(String quotedVersion) {
        this.quotedVersion = quotedVersion == null ? null : quotedVersion.trim();
    }

    public String getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(String unitPrice) {
        this.unitPrice = unitPrice == null ? null : unitPrice.trim();
    }
}