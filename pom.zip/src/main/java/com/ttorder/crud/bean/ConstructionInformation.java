package com.ttorder.crud.bean;

import java.util.Date;

import com.alibaba.fastjson.annotation.JSONField;

public class ConstructionInformation {
    private String constructionId;

    private String orderNo;

    private String constructionType;

    private String operator;

    private String propertyId;

    private String propertyContactId;

    private String developerId;

    private String cellId;

    @JSONField (format="yyyy-MM-dd")
    private Date completionDate;

    private String electricityFetchingMode;

    private String electricityFetchingAddress;

    private String parkingType;

    private String parkingNo;

    private String propertyPerson;

    private String ownerPerson;

    private String selfmoney;

    private String remakes;
    @JSONField (format="yyyy-MM-dd")
    private Date contactDate;

    @JSONField (format="yyyy-MM-dd")
    private Date contactDateNext;

    private String architecturalType;

    private String electricalPower;

    private String cableType;

    private String cableLen;

    private String singleThree;

    private String installationEnvironment;

    private String developerPerson;

    private String otherRemarks;

    @JSONField (format="yyyy-MM-dd")
    private Date ortherDate;

    public String getConstructionId() {
        return constructionId;
    }

    public void setConstructionId(String constructionId) {
        this.constructionId = constructionId == null ? null : constructionId.trim();
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo == null ? null : orderNo.trim();
    }

    public String getConstructionType() {
        return constructionType;
    }

    public void setConstructionType(String constructionType) {
        this.constructionType = constructionType == null ? null : constructionType.trim();
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator == null ? null : operator.trim();
    }

    public String getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(String propertyId) {
        this.propertyId = propertyId == null ? null : propertyId.trim();
    }

    public String getPropertyContactId() {
        return propertyContactId;
    }

    public void setPropertyContactId(String propertyContactId) {
        this.propertyContactId = propertyContactId == null ? null : propertyContactId.trim();
    }

    public String getDeveloperId() {
        return developerId;
    }

    public void setDeveloperId(String developerId) {
        this.developerId = developerId == null ? null : developerId.trim();
    }

    public String getCellId() {
        return cellId;
    }

    public void setCellId(String cellId) {
        this.cellId = cellId == null ? null : cellId.trim();
    }

    public Date getCompletionDate() {
        return completionDate;
    }

    public void setCompletionDate(Date completionDate) {
        this.completionDate = completionDate;
    }

    public String getElectricityFetchingMode() {
        return electricityFetchingMode;
    }

    public void setElectricityFetchingMode(String electricityFetchingMode) {
        this.electricityFetchingMode = electricityFetchingMode == null ? null : electricityFetchingMode.trim();
    }

    public String getElectricityFetchingAddress() {
        return electricityFetchingAddress;
    }

    public void setElectricityFetchingAddress(String electricityFetchingAddress) {
        this.electricityFetchingAddress = electricityFetchingAddress == null ? null : electricityFetchingAddress.trim();
    }

    public String getParkingType() {
        return parkingType;
    }

    public void setParkingType(String parkingType) {
        this.parkingType = parkingType == null ? null : parkingType.trim();
    }

    public String getParkingNo() {
        return parkingNo;
    }

    public void setParkingNo(String parkingNo) {
        this.parkingNo = parkingNo == null ? null : parkingNo.trim();
    }

    public String getPropertyPerson() {
        return propertyPerson;
    }

    public void setPropertyPerson(String propertyPerson) {
        this.propertyPerson = propertyPerson == null ? null : propertyPerson.trim();
    }

    public String getOwnerPerson() {
        return ownerPerson;
    }

    public void setOwnerPerson(String ownerPerson) {
        this.ownerPerson = ownerPerson == null ? null : ownerPerson.trim();
    }

    public String getSelfmoney() {
        return selfmoney;
    }

    public void setSelfmoney(String selfmoney) {
        this.selfmoney = selfmoney == null ? null : selfmoney.trim();
    }

    public String getRemakes() {
        return remakes;
    }

    public void setRemakes(String remakes) {
        this.remakes = remakes == null ? null : remakes.trim();
    }

    public Date getContactDate() {
        return contactDate;
    }

    public void setContactDate(Date contactDate) {
        this.contactDate = contactDate;
    }

    public Date getContactDateNext() {
        return contactDateNext;
    }

    public void setContactDateNext(Date contactDateNext) {
        this.contactDateNext = contactDateNext;
    }

    public String getArchitecturalType() {
        return architecturalType;
    }

    public void setArchitecturalType(String architecturalType) {
        this.architecturalType = architecturalType == null ? null : architecturalType.trim();
    }

    public String getElectricalPower() {
        return electricalPower;
    }

    public void setElectricalPower(String electricalPower) {
        this.electricalPower = electricalPower == null ? null : electricalPower.trim();
    }

    public String getCableType() {
        return cableType;
    }

    public void setCableType(String cableType) {
        this.cableType = cableType == null ? null : cableType.trim();
    }

    public String getCableLen() {
        return cableLen;
    }

    public void setCableLen(String cableLen) {
        this.cableLen = cableLen == null ? null : cableLen.trim();
    }

    public String getSingleThree() {
        return singleThree;
    }

    public void setSingleThree(String singleThree) {
        this.singleThree = singleThree == null ? null : singleThree.trim();
    }

    public String getInstallationEnvironment() {
        return installationEnvironment;
    }

    public void setInstallationEnvironment(String installationEnvironment) {
        this.installationEnvironment = installationEnvironment == null ? null : installationEnvironment.trim();
    }

    public String getDeveloperPerson() {
        return developerPerson;
    }

    public void setDeveloperPerson(String developerPerson) {
        this.developerPerson = developerPerson == null ? null : developerPerson.trim();
    }

    public String getOtherRemarks() {
        return otherRemarks;
    }

    public void setOtherRemarks(String otherRemarks) {
        this.otherRemarks = otherRemarks == null ? null : otherRemarks.trim();
    }

    public Date getOrtherDate() {
        return ortherDate;
    }

    public void setOrtherDate(Date ortherDate) {
        this.ortherDate = ortherDate;
    }
}