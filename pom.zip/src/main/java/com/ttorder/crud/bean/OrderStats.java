package com.ttorder.crud.bean;


 public enum OrderStats{
        
        NEWBUILD(1,"新建"),
        IN_SURVEY(2,"勘测中"),
        IN_SURVEY_AFTER(3,"勘测审核中"),
        INSTALLATION(4,"安装中"),
        INSTALLATION_AFTER(5,"安装审核中"),
        IN_VISIT(6,"回访中"),
        CLOSE(7,"订单结束");
        
        private OrderStats(Integer value,String name){
            this.value = value;
            this.name = name;
        }
        private final Integer value;
        private final String name;
        
        public Integer getValue() {
            return value;
        }

        public String getName() {
            return name;
        }
        
    }