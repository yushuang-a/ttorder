package com.ttorder.crud.bean;

public class MaterialToolInformation {
    private Integer materialId;

    private String materialScienceId;

    private String materialClass;

    private String materialToolName;

    private String materialBrand;

    private String specificationType;

    private String unit;

    private String toolState;

    private String toolPicture;
    
    private QuotationInformation quotationInformation;

    public QuotationInformation getQuotationInformation() {
		return quotationInformation;
	}

	public void setQuotationInformation(QuotationInformation quotationInformation) {
		this.quotationInformation = quotationInformation;
	}

	public Integer getMaterialId() {
        return materialId;
    }

    public void setMaterialId(Integer materialId) {
        this.materialId = materialId;
    }

    public String getMaterialScienceId() {
        return materialScienceId;
    }

    public void setMaterialScienceId(String materialScienceId) {
        this.materialScienceId = materialScienceId == null ? null : materialScienceId.trim();
    }

    public String getMaterialClass() {
        return materialClass;
    }

    public void setMaterialClass(String materialClass) {
        this.materialClass = materialClass == null ? null : materialClass.trim();
    }

    public String getMaterialToolName() {
        return materialToolName;
    }

    public void setMaterialToolName(String materialToolName) {
        this.materialToolName = materialToolName == null ? null : materialToolName.trim();
    }

    public String getMaterialBrand() {
        return materialBrand;
    }

    public void setMaterialBrand(String materialBrand) {
        this.materialBrand = materialBrand == null ? null : materialBrand.trim();
    }

    public String getSpecificationType() {
        return specificationType;
    }

    public void setSpecificationType(String specificationType) {
        this.specificationType = specificationType == null ? null : specificationType.trim();
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit == null ? null : unit.trim();
    }

    public String getToolState() {
        return toolState;
    }

    public void setToolState(String toolState) {
        this.toolState = toolState == null ? null : toolState.trim();
    }

    public String getToolPicture() {
        return toolPicture;
    }

    public void setToolPicture(String toolPicture) {
        this.toolPicture = toolPicture == null ? null : toolPicture.trim();
    }
}