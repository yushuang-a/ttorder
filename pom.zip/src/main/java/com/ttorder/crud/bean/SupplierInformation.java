package com.ttorder.crud.bean;

public class SupplierInformation {
    private Integer supplierId;

    private String businessClass;

    private String businessFullName;

    private String businessShortName;

    private String businessCode;

    private String businessNo;

    private String businessAdress;

    private String businessOpenBank;

    private String bankAccount;

    private String taxCode;

    public Integer getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Integer supplierId) {
        this.supplierId = supplierId;
    }

    public String getBusinessClass() {
        return businessClass;
    }

    public void setBusinessClass(String businessClass) {
        this.businessClass = businessClass == null ? null : businessClass.trim();
    }

    public String getBusinessFullName() {
        return businessFullName;
    }

    public void setBusinessFullName(String businessFullName) {
        this.businessFullName = businessFullName == null ? null : businessFullName.trim();
    }

    public String getBusinessShortName() {
        return businessShortName;
    }

    public void setBusinessShortName(String businessShortName) {
        this.businessShortName = businessShortName == null ? null : businessShortName.trim();
    }

    public String getBusinessCode() {
        return businessCode;
    }

    public void setBusinessCode(String businessCode) {
        this.businessCode = businessCode == null ? null : businessCode.trim();
    }

    public String getBusinessNo() {
        return businessNo;
    }

    public void setBusinessNo(String businessNo) {
        this.businessNo = businessNo == null ? null : businessNo.trim();
    }

    public String getBusinessAdress() {
        return businessAdress;
    }

    public void setBusinessAdress(String businessAdress) {
        this.businessAdress = businessAdress == null ? null : businessAdress.trim();
    }

    public String getBusinessOpenBank() {
        return businessOpenBank;
    }

    public void setBusinessOpenBank(String businessOpenBank) {
        this.businessOpenBank = businessOpenBank == null ? null : businessOpenBank.trim();
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount == null ? null : bankAccount.trim();
    }

    public String getTaxCode() {
        return taxCode;
    }

    public void setTaxCode(String taxCode) {
        this.taxCode = taxCode == null ? null : taxCode.trim();
    }
}