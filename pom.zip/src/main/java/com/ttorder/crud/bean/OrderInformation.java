package com.ttorder.crud.bean;

import java.io.Serializable;
import java.util.Date;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;

public class OrderInformation implements Serializable {
    private Integer orderId;

    private String orderNo;

    private String orderClass;

    @JSONField (format="yyyy-MM-dd")  
    private Date orderDate;

    private String rd;

    private String cd;

    private String carNo;

    private String chargerId;

    private String brand;

    private String carType;

    private String distributorName;//经销商名称

    private String distributorContactsName;

    private String ownerName;

    private String ownerNo;

    private String ownerGender;

    private String ownerContactsName;

    private String ownerContactsNo;

    private String ownerContactsGender;

    private String province;

    private String city;

    private String ownerInsAddress;

    private String freeName;

    private String customerServiceName;

    private String serviceRemarks;

    @JSONField (format="yyyy-MM-dd")  
    private Date dateUpload;

    private String requestStatus;

    private String invoiceStatus;

    private Integer orderStatus;

    private String installer;//安装

    private String surveyor;//勘测

    private String revisitors;//客服

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo == null ? null : orderNo.trim();
    }

    public String getOrderClass() {
        return orderClass;
    }

    public void setOrderClass(String orderClass) {
        this.orderClass = orderClass == null ? null : orderClass.trim();
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public String getRd() {
        return rd;
    }

    public void setRd(String rd) {
        this.rd = rd == null ? null : rd.trim();
    }

    public String getCd() {
        return cd;
    }

    public void setCd(String cd) {
        this.cd = cd == null ? null : cd.trim();
    }

    public String getCarNo() {
        return carNo;
    }

    public void setCarNo(String carNo) {
        this.carNo = carNo == null ? null : carNo.trim();
    }

    public String getChargerId() {
        return chargerId;
    }

    public void setChargerId(String chargerId) {
        this.chargerId = chargerId == null ? null : chargerId.trim();
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand == null ? null : brand.trim();
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType == null ? null : carType.trim();
    }

    public String getDistributorName() {
        return distributorName;
    }

    public void setDistributorName(String distributorName) {
        this.distributorName = distributorName == null ? null : distributorName.trim();
    }

    public String getDistributorContactsName() {
        return distributorContactsName;
    }

    public void setDistributorContactsName(String distributorContactsName) {
        this.distributorContactsName = distributorContactsName == null ? null : distributorContactsName.trim();
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName == null ? null : ownerName.trim();
    }

    public String getOwnerNo() {
        return ownerNo;
    }

    public void setOwnerNo(String ownerNo) {
        this.ownerNo = ownerNo == null ? null : ownerNo.trim();
    }

    public String getOwnerGender() {
        return ownerGender;
    }

    public void setOwnerGender(String ownerGender) {
        this.ownerGender = ownerGender == null ? null : ownerGender.trim();
    }

    public String getOwnerContactsName() {
        return ownerContactsName;
    }

    public void setOwnerContactsName(String ownerContactsName) {
        this.ownerContactsName = ownerContactsName == null ? null : ownerContactsName.trim();
    }

    public String getOwnerContactsNo() {
        return ownerContactsNo;
    }

    public void setOwnerContactsNo(String ownerContactsNo) {
        this.ownerContactsNo = ownerContactsNo == null ? null : ownerContactsNo.trim();
    }

    public String getOwnerContactsGender() {
        return ownerContactsGender;
    }

    public void setOwnerContactsGender(String ownerContactsGender) {
        this.ownerContactsGender = ownerContactsGender == null ? null : ownerContactsGender.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public String getOwnerInsAddress() {
        return ownerInsAddress;
    }

    public void setOwnerInsAddress(String ownerInsAddress) {
        this.ownerInsAddress = ownerInsAddress == null ? null : ownerInsAddress.trim();
    }

    public String getFreeName() {
        return freeName;
    }

    public void setFreeName(String freeName) {
        this.freeName = freeName == null ? null : freeName.trim();
    }

    public String getCustomerServiceName() {
        return customerServiceName;
    }

    public void setCustomerServiceName(String customerServiceName) {
        this.customerServiceName = customerServiceName == null ? null : customerServiceName.trim();
    }

    public String getServiceRemarks() {
        return serviceRemarks;
    }

    public void setServiceRemarks(String serviceRemarks) {
        this.serviceRemarks = serviceRemarks == null ? null : serviceRemarks.trim();
    }

    public Date getDateUpload() {
        return dateUpload;
    }

    public void setDateUpload(Date dateUpload) {
        this.dateUpload = dateUpload;
    }

    public String getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus == null ? null : requestStatus.trim();
    }

    public String getInvoiceStatus() {
        return invoiceStatus;
    }

    public void setInvoiceStatus(String invoiceStatus) {
        this.invoiceStatus = invoiceStatus == null ? null : invoiceStatus.trim();
    }

    public Integer getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getInstaller() {
        return installer;
    }

    public void setInstaller(String installer) {
        this.installer = installer == null ? null : installer.trim();
    }

    public String getSurveyor() {
        return surveyor;
    }

    public void setSurveyor(String surveyor) {
        this.surveyor = surveyor == null ? null : surveyor.trim();
    }

    public String getRevisitors() {
        return revisitors;
    }

    public void setRevisitors(String revisitors) {
        this.revisitors = revisitors == null ? null : revisitors.trim();
    }
}