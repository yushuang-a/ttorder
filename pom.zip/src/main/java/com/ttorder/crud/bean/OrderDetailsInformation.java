package com.ttorder.crud.bean;

public class OrderDetailsInformation {
    private Integer amoneyId;

    private String constructionId;

    private String materialScienceId;

    private Integer amount;

    private Double unitPrice;

    private String remarks;

    private String orderNo;

    private String materialToolName;

    private String materialBrand;

    private String unit;

    public Integer getAmoneyId() {
        return amoneyId;
    }

    public void setAmoneyId(Integer amoneyId) {
        this.amoneyId = amoneyId;
    }

    public String getConstructionId() {
        return constructionId;
    }

    public void setConstructionId(String constructionId) {
        this.constructionId = constructionId == null ? null : constructionId.trim();
    }

    public String getMaterialScienceId() {
        return materialScienceId;
    }

    public void setMaterialScienceId(String materialScienceId) {
        this.materialScienceId = materialScienceId == null ? null : materialScienceId.trim();
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(Double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks == null ? null : remarks.trim();
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo == null ? null : orderNo.trim();
    }

    public String getMaterialToolName() {
        return materialToolName;
    }

    public void setMaterialToolName(String materialToolName) {
        this.materialToolName = materialToolName == null ? null : materialToolName.trim();
    }

    public String getMaterialBrand() {
        return materialBrand;
    }

    public void setMaterialBrand(String materialBrand) {
        this.materialBrand = materialBrand == null ? null : materialBrand.trim();
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit == null ? null : unit.trim();
    }
}