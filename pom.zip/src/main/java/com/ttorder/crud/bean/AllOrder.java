
package com.ttorder.crud.bean;

/** 
* @author 	yushuang
* @version 	2019年7月26日  上午9:47:25 
*  
*/
//订单完整信息
public class AllOrder {
	
		private String order_no;
		
		private OrderInformation orderInformation;//订单基础信息
	
	 	private ConstructionInformation constructionInformation;//施工单
	    
	    private SupplierInformation supplierInformation;//供应商单

		private QuotationInformation quotationInformation;//报价单
	    
	    private ReturnsurFaceInformation returnsurFaceInformation;//回访单

		public String getOrder_no() {
			return order_no;
		}

		public void setOrder_no(String order_no) {
			this.order_no = order_no;
		}

		public OrderInformation getOrderInformation() {
			return orderInformation;
		}

		public void setOrderInformation(OrderInformation orderInformation) {
			this.orderInformation = orderInformation;
		}

		public ConstructionInformation getConstructionInformation() {
			return constructionInformation;
		}

		public void setConstructionInformation(ConstructionInformation constructionInformation) {
			this.constructionInformation = constructionInformation;
		}

		public SupplierInformation getSupplierInformation() {
			return supplierInformation;
		}

		public void setSupplierInformation(SupplierInformation supplierInformation) {
			this.supplierInformation = supplierInformation;
		}

		public QuotationInformation getQuotationInformation() {
			return quotationInformation;
		}

		public void setQuotationInformation(QuotationInformation quotationInformation) {
			this.quotationInformation = quotationInformation;
		}

		public ReturnsurFaceInformation getReturnsurFaceInformation() {
			return returnsurFaceInformation;
		}

		public void setReturnsurFaceInformation(ReturnsurFaceInformation returnsurFaceInformation) {
			this.returnsurFaceInformation = returnsurFaceInformation;
		}

	    
}
