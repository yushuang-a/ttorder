package com.ttorder.crud.bean;

public class CellInformation {
    private Integer cellId;

    private String cellName;

    private String province;

    private String city;

    private String cellAddress;

    private String propertyId;

    private String propertyContactsId;

    private String installationStatus;

    private String developersId;

    private String developersContactsId;

    private String powerSupply;

    public Integer getCellId() {
        return cellId;
    }

    public void setCellId(Integer cellId) {
        this.cellId = cellId;
    }

    public String getCellName() {
        return cellName;
    }

    public void setCellName(String cellName) {
        this.cellName = cellName == null ? null : cellName.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public String getCellAddress() {
        return cellAddress;
    }

    public void setCellAddress(String cellAddress) {
        this.cellAddress = cellAddress == null ? null : cellAddress.trim();
    }

    public String getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(String propertyId) {
        this.propertyId = propertyId == null ? null : propertyId.trim();
    }

    public String getPropertyContactsId() {
        return propertyContactsId;
    }

    public void setPropertyContactsId(String propertyContactsId) {
        this.propertyContactsId = propertyContactsId == null ? null : propertyContactsId.trim();
    }

    public String getInstallationStatus() {
        return installationStatus;
    }

    public void setInstallationStatus(String installationStatus) {
        this.installationStatus = installationStatus == null ? null : installationStatus.trim();
    }

    public String getDevelopersId() {
        return developersId;
    }

    public void setDevelopersId(String developersId) {
        this.developersId = developersId == null ? null : developersId.trim();
    }

    public String getDevelopersContactsId() {
        return developersContactsId;
    }

    public void setDevelopersContactsId(String developersContactsId) {
        this.developersContactsId = developersContactsId == null ? null : developersContactsId.trim();
    }

    public String getPowerSupply() {
        return powerSupply;
    }

    public void setPowerSupply(String powerSupply) {
        this.powerSupply = powerSupply == null ? null : powerSupply.trim();
    }
}