package com.ttorder.crud.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ttorder.crud.bean.CellInformation;

public interface CellInformationMapper {
    int deleteByPrimaryKey(Integer cellId);

    int insert(CellInformation record);

    int insertSelective(CellInformation record);

    CellInformation selectByPrimaryKey(Integer cellId);

    int updateByPrimaryKeySelective(CellInformation record);

    int updateByPrimaryKey(CellInformation record);
    
    List<CellInformation> selectAllCell();
	
	List<CellInformation> selectCellByClass(@Param("str") String str,@Param("str") String value);
	
	String getCellName(Integer cellId);
}