package com.ttorder.crud.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ttorder.crud.bean.OrderInformation;

public interface OrderInformationMapper {
    int deleteByPrimaryKey(Integer orderId);

    int insert(OrderInformation record);

    int insertSelective(OrderInformation record);

    OrderInformation selectByPrimaryKey(Integer orderId);

    int updateByPrimaryKeySelective(OrderInformation record);

    int updateByPrimaryKey(OrderInformation record);
    
    List<OrderInformation> selectByOrderStatus(Integer orderStatus);
    //根据订单号修改状态码
    void updateOrderStatsByOrderNo(@Param("orderNo")String orderNo,@Param("orderStatus")Integer orderStatus);

    OrderInformation selectByorderNo(String orderNo);
    
    boolean selectByorderNoIsEM(String orderNo);
    
    List<OrderInformation> selectByemp(@Param("empId")Integer empId,@Param("department")Integer departmentType);
    
    void updateInstaller(@Param("orderNo")String orderNo,@Param("empId")Integer empId);
    
    List<OrderInformation> selectAllOrderWithNull();
    
    List<OrderInformation> selectOrderWithLike(@Param("str")String str,@Param("value")String value);

	void updateremarksToNew(@Param("orderNo")String orderNo, @Param("newremakes")String newremakes);
}