package com.ttorder.crud.dao;

import java.util.List;

import com.ttorder.crud.bean.MaterialToolInformation;

public interface MaterialToolInformationMapper {
    int deleteByPrimaryKey(Integer materialId);

    int insert(MaterialToolInformation record);

    int insertSelective(MaterialToolInformation record);

    MaterialToolInformation selectByPrimaryKey(Integer materialId);

    //根据物料类别查询
    List<MaterialToolInformation> selectByMaterialClass(String materialClass);
    
    //查询所有物料带报价
    
    List<MaterialToolInformation> selectWithQue();
    
    int updateByPrimaryKeySelective(MaterialToolInformation record);

    int updateByPrimaryKey(MaterialToolInformation record);
    
    
    List<MaterialToolInformation> selectmtByname(String mtname);
}