package com.ttorder.crud.dao;

import java.util.List;

import com.ttorder.crud.bean.ReturnsurFaceInformation;

public interface ReturnsurFaceInformationMapper {
    int deleteByPrimaryKey(Integer returnId);

    int insert(ReturnsurFaceInformation record);

    int insertSelective(ReturnsurFaceInformation record);

    ReturnsurFaceInformation selectByPrimaryKey(Integer returnId);
    
    List<ReturnsurFaceInformation> selectByOrderNo(String orderNo);

    int updateByPrimaryKeySelective(ReturnsurFaceInformation record);

    int updateByPrimaryKey(ReturnsurFaceInformation record);
}