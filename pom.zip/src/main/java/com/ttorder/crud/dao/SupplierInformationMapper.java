package com.ttorder.crud.dao;

import java.util.List;

import com.ttorder.crud.bean.SupplierInformation;

public interface SupplierInformationMapper {
    int deleteByPrimaryKey(int supplierId);

    int insert(SupplierInformation record);

    int insertSelective(SupplierInformation record);

    SupplierInformation selectByPrimaryKey(Integer supplierId);
    
    List<SupplierInformation> selectAllSup();//查询所有经销商

    int updateByPrimaryKeySelective(SupplierInformation record);

    int updateByPrimaryKey(SupplierInformation record);

	List<SupplierInformation> searchDisByClass(String businessClass);
	
	String selectNameById(Integer supId);
	
}