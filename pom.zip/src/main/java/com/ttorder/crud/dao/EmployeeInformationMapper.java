package com.ttorder.crud.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ttorder.crud.bean.EmployeeInformation;

public interface EmployeeInformationMapper {
    int deleteByPrimaryKey(Integer employeeId);

    int insert(EmployeeInformation record);

    int insertSelective(EmployeeInformation record);

    EmployeeInformation selectByPrimaryKey(Integer employeeId);
    
    EmployeeInformation selectByTelephone(String telephone);

    List<EmployeeInformation> selectAllEmp();
    
    int updateByPrimaryKeySelective(EmployeeInformation record);

    int updateByPrimaryKey(EmployeeInformation record);
    
    String selectBytel(String telephone);

	List<EmployeeInformation> searchEmpByemployeeClass(String employeeClass);

	List<EmployeeInformation> searchEmpByType(@Param("str") String str,@Param("value") String value);
	
	String selectNameByempId(Integer empId);
}