package com.ttorder.crud.dao;

import java.util.List;

import com.ttorder.crud.bean.ImgInformation;

public interface ImgInformationMapper {
    int deleteByPrimaryKey(Integer uid);

    int insert(ImgInformation record);

    int insertSelective(ImgInformation record);

    List<ImgInformation> selectByPrimaryKey(Integer uid);

    int updateByPrimaryKeySelective(ImgInformation record);

    int updateByPrimaryKey(ImgInformation record);

	List<ImgInformation> selectByIdcode(String idcode);
}