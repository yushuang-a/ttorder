package com.ttorder.crud.dao;

import com.ttorder.crud.bean.QuotationInformation;

import java.util.List;

public interface QuotationInformationMapper {
    int deleteByPrimaryKey(Integer quotationSheetId);

    int insert(QuotationInformation record);

    int insertSelective(QuotationInformation record);

    QuotationInformation selectByPrimaryKey(Integer quotationSheetId);

    int updateByPrimaryKeySelective(QuotationInformation record);

    int updateByPrimaryKey(QuotationInformation record);

    List<QuotationInformation> selectAllBymtId(String materialScienceId);
}