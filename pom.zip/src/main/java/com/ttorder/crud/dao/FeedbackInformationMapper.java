package com.ttorder.crud.dao;

import java.util.List;

import com.ttorder.crud.bean.FeedbackInformation;

public interface FeedbackInformationMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(FeedbackInformation record);

    int insertSelective(FeedbackInformation record);

    FeedbackInformation selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(FeedbackInformation record);

    int updateByPrimaryKey(FeedbackInformation record);

	List<FeedbackInformation> getAllFeed(String orderNo);
}