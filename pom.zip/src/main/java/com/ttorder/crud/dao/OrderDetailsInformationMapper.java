package com.ttorder.crud.dao;

import java.util.List;

import com.ttorder.crud.bean.OrderDetailsInformation;

public interface OrderDetailsInformationMapper {
    int deleteByPrimaryKey(Integer amoneyId);

    int insert(OrderDetailsInformation record);

    int insertSelective(OrderDetailsInformation record);

    OrderDetailsInformation selectByPrimaryKey(Integer amoneyId);

    int updateByPrimaryKeySelective(OrderDetailsInformation record);

    int updateByPrimaryKey(OrderDetailsInformation record);
    
    List<OrderDetailsInformation> selectDetailsByConstructionId(String constructionId);
}