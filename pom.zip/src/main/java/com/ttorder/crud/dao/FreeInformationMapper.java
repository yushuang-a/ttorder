package com.ttorder.crud.dao;

import java.util.List;

import com.ttorder.crud.bean.FreeInformation;

public interface FreeInformationMapper {
    int deleteByPrimaryKey(Integer freeId);

    int insert(FreeInformation record);

    int insertSelective(FreeInformation record);

    FreeInformation selectByPrimaryKey(Integer freeId);

    int updateByPrimaryKeySelective(FreeInformation record);

    int updateByPrimaryKey(FreeInformation record);

	List<FreeInformation> selectAll();
}