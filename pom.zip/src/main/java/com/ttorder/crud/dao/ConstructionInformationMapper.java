package com.ttorder.crud.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ttorder.crud.bean.ConstructionInformation;

public interface ConstructionInformationMapper {
    int deleteByPrimaryKey(String constructionId);

    int insert(ConstructionInformation record);

    int insertSelective(ConstructionInformation record);

    ConstructionInformation selectByPrimaryKey(String constructionId);

    int updateByPrimaryKeySelective(ConstructionInformation record);

    int updateByPrimaryKey(ConstructionInformation record);
    
    List<ConstructionInformation> selectByOrderNO(@Param("orderNo")String orderNo, @Param("constructionType")String constructionType);
}