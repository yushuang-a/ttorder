
package com.ttorder.crud.service;

import java.util.List;

import com.ttorder.crud.bean.ImgInformation;

/** 
* @author 	yushuang
* @version 	2019年8月24日  下午4:46:59 
*  
*/

public interface ImgService {

	void addImg(ImgInformation imgInformation);

	List<ImgInformation> getAllImg(String idcode);

}
