
package com.ttorder.crud.service;

import java.util.List;

import com.ttorder.crud.bean.EmployeeInformation;

/** 
* @author 	yushuang
* @version 	2019年7月25日  下午4:08:39 
*  
*/

public interface EmployeeInformationService {

	void addEmp(EmployeeInformation employeeInformation);
	
	void updateEmp(EmployeeInformation employeeInformation);
	
	void deleteEmp(Integer employeeId);
	
	List<EmployeeInformation> selectEmp();

	List<EmployeeInformation> searchEmp(String employeeClass);

	List<EmployeeInformation> selectAllInfo(String str, String value);

	EmployeeInformation selectEmpById(Integer empId);
	
}
