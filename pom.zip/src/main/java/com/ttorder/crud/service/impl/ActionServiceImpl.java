
package com.ttorder.crud.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.EmployeeInformation;
import com.ttorder.crud.dao.EmployeeInformationMapper;
import com.ttorder.crud.service.ActionService;

/** 
* @author 	yushuang
* @version 	2019年8月2日  上午10:39:53 
*  
*/
@Service
public class ActionServiceImpl implements ActionService {

	@Autowired
	private EmployeeInformationMapper employeeInformationMapper;
	
	@Override
	public String login(String telephone) {
		// TODO Auto-generated method stub
		
		return employeeInformationMapper.selectBytel(telephone);
	}

	@Override
	public EmployeeInformation loginInfo(String telephone) {
		// TODO Auto-generated method stub
		
		
		return employeeInformationMapper.selectByTelephone(telephone);
	}

}
