
package com.ttorder.crud.service.impl;

import java.util.List;

import org.apache.ibatis.javassist.tools.framedump;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.FreeInformation;
import com.ttorder.crud.dao.FreeInformationMapper;
import com.ttorder.crud.service.FreeInformationService;

/** 
* @author 	yushuang
* @version 	2019年8月30日  下午2:18:34 
*  
*/
@Service
public class FreeInformationServiceImpl implements FreeInformationService {

	@Autowired
	private FreeInformationMapper freeInformationMapper;
	
	@Override
	public void addfree(FreeInformation freeInfo) {
		// TODO Auto-generated method stub
		freeInformationMapper.insertSelective(freeInfo);
	}

	@Override
	public void deletefree(Integer id) {
		// TODO Auto-generated method stub
		freeInformationMapper.deleteByPrimaryKey(id);
	}

	@Override
	public void updatefree(FreeInformation freeInfo) {
		// TODO Auto-generated method stub
		freeInformationMapper.updateByPrimaryKeySelective(freeInfo);
	}

	@Override
	public List<FreeInformation> selectfree() {
		// TODO Auto-generated method stub
		return freeInformationMapper.selectAll();
	}

}
