
package com.ttorder.crud.service;

/** 
* @author 	yushuang
* @version 	2019年9月17日  下午7:01:43 
*  
*/

public interface WeChatService {
	
	void sendWeChat(String touser,String msg);
	
}
