
package com.ttorder.crud.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestParam;

import com.ttorder.crud.bean.CellInformation;

/** 
* @author 	yushuang
* @version 	2019年8月30日  下午2:27:34 
*  
*/

public interface CellInformationService {

	void addCellInfo(CellInformation cellInfo);
	
	void updateCellInfo(CellInformation cellInfo);
	
	void deleteCellInfo(Integer cellId);
	
	List<CellInformation> selectCellInfo();

	List<CellInformation> selectByClass(String str,String value);
}
