
package com.ttorder.crud.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.CellInformation;
import com.ttorder.crud.dao.CellInformationMapper;
import com.ttorder.crud.dao.EmployeeInformationMapper;
import com.ttorder.crud.dao.SupplierInformationMapper;
import com.ttorder.crud.service.CellInformationService;

/** 
* @author 	yushuang
* @version 	2019年8月30日  下午2:36:19 
*  
*/
@Service
public class CellInformationServiceImpl implements CellInformationService {

	@Autowired
	private CellInformationMapper cellInformationMapper;
	@Autowired
	private EmployeeInformationMapper employeeInformationMapper;
	@Autowired
	private SupplierInformationMapper supplierInformationMapper;
	@Override
	public void addCellInfo(CellInformation cellInfo) {
		// TODO Auto-generated method stub
		cellInformationMapper.insertSelective(cellInfo);
	}

	@Override
	public void updateCellInfo(CellInformation cellInfo) {
		// TODO Auto-generated method stub
		cellInformationMapper.updateByPrimaryKeySelective(cellInfo);
	}

	@Override
	public void deleteCellInfo(Integer cellId) {
		// TODO Auto-generated method stub
		cellInformationMapper.deleteByPrimaryKey(cellId);
	}

	@Override
	public List<CellInformation> selectCellInfo() {
		// TODO Auto-generated method stub
		
		List<CellInformation> list = cellInformationMapper.selectAllCell();
		for (CellInformation cellInformation : list) {
			
			if(!cellInformation.getPropertyId().equals(null)) {
				cellInformation.setPropertyId(supplierInformationMapper.selectNameById(toIneger(cellInformation.getPropertyId())));	
			}
			if(!cellInformation.getPropertyContactsId().equals(null)) {
				cellInformation.setPropertyContactsId(employeeInformationMapper.selectNameByempId(toIneger(cellInformation.getPropertyContactsId())));
			}
			if(!cellInformation.getDevelopersId().equals(null)) {
				cellInformation.setDevelopersId(supplierInformationMapper.selectNameById(toIneger(cellInformation.getDevelopersId())));
			}
			if(!cellInformation.getDevelopersContactsId().equals(null)) {
				cellInformation.setDevelopersContactsId(employeeInformationMapper.selectNameByempId(toIneger(cellInformation.getDevelopersContactsId())));
			}

		}
		return list;
	}

	@Override
	public List<CellInformation> selectByClass(String str, String value) {
		// TODO Auto-generated method stub
		List<CellInformation> list = cellInformationMapper.selectCellByClass(str, value);
		
		//将id转化为中文名字输出
		for (CellInformation cellInformation : list) {
			
			if(!cellInformation.getPropertyId().equals(null)) {
				cellInformation.setPropertyId(supplierInformationMapper.selectNameById(toIneger(cellInformation.getPropertyId())));	
			}
			if(!cellInformation.getPropertyContactsId().equals(null)) {
				cellInformation.setPropertyContactsId(employeeInformationMapper.selectNameByempId(toIneger(cellInformation.getPropertyContactsId())));
			}
			if(!cellInformation.getDevelopersId().equals(null)) {
				cellInformation.setDevelopersId(supplierInformationMapper.selectNameById(toIneger(cellInformation.getDevelopersId())));
			}
			if(!cellInformation.getDevelopersContactsId().equals(null)) {
				cellInformation.setDevelopersContactsId(employeeInformationMapper.selectNameByempId(toIneger(cellInformation.getDevelopersContactsId())));
			}

		}
		return list;
	}

	
	public static Integer toIneger(String str) {
		return Integer.valueOf(str);
	}
}
