
package com.ttorder.crud.service;

import java.util.List;

import com.ttorder.crud.bean.OrderDetailsInformation;

/** 
* @author 	yushuang
* @version 	2019年8月7日  下午3:52:17 
*  
*/

public interface OrderDetailsInformationService {

	void addDetails(OrderDetailsInformation orderDetailsInformation);
	
	List<OrderDetailsInformation> selectOrderDetailsById(String constructionId);
	
}
