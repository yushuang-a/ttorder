
package com.ttorder.crud.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.OrderDetailsInformation;
import com.ttorder.crud.dao.OrderDetailsInformationMapper;
import com.ttorder.crud.service.OrderDetailsInformationService;

/** 
* @author 	yushuang
* @version 	2019年8月7日  下午3:59:12 
*  
*/
@Service
public class OrderDetailsInformationServiceImpl implements OrderDetailsInformationService {

	@Autowired
	private OrderDetailsInformationMapper orderDetailsInformationMapper;
	@Override
	public void addDetails(OrderDetailsInformation orderDetailsInformation) {
		// TODO Auto-generated method stub
		
		orderDetailsInformationMapper.insertSelective(orderDetailsInformation);
		
	}
	@Override
	public List<OrderDetailsInformation> selectOrderDetailsById(String constructionId) {
		// TODO Auto-generated method stub
		return orderDetailsInformationMapper.selectDetailsByConstructionId(constructionId);
	}

}
