
package com.ttorder.crud.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.ReturnsurFaceInformation;

/** 
* @author 	yushuang
* @version 	2019��7��24��  ����5:38:38 
*  
*/
public interface ReturnsurFaceInformationService {

	void addReturnsurFaceInformation(ReturnsurFaceInformation returnsurFaceInformation);

	List<ReturnsurFaceInformation> selectReturnByOrderNo(String orderNo);

}
