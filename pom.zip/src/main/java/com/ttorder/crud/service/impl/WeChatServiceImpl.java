
package com.ttorder.crud.service.impl;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.WeChatUrlData;
import com.ttorder.crud.service.WeChatService;
import com.ttorder.crud.utils.WeChatMsgSend;

/** 
* @author 	yushuang
* @version 	2019年9月17日  下午7:03:13 
*  
*/
@Service
public class WeChatServiceImpl implements WeChatService {

	@Override
	public void sendWeChat(String touser, String msg) {
		WeChatMsgSend  weChatMsgSend = new WeChatMsgSend();
		 try {
	            String token = weChatMsgSend.getToken("ww474a3e31e94f9f71","8qdD5vHONm9d-4f86HvhLc0o8wlJzATY9adjtVdsdDs");
	            String postdata = weChatMsgSend.createpostdata(touser, "text", 1000017, "content",msg);
	            String resp = weChatMsgSend.post("utf-8", WeChatMsgSend.CONTENT_TYPE,(new WeChatUrlData()).getSendMessage_Url(), postdata, token);
	            System.out.println("获取到的token======>" + token);
	            System.out.println("请求数据======>" + postdata);
	            System.out.println("发送微信的响应数据======>" + resp);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		
	}

}
