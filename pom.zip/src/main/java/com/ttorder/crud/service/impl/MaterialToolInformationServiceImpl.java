
package com.ttorder.crud.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.MaterialToolInformation;
import com.ttorder.crud.dao.MaterialToolInformationMapper;
import com.ttorder.crud.service.MaterialToolInformationService;

/** 
* @author 	yushuang
* @version 	2019年8月5日  下午3:31:17 
*  
*/
@Service
public class MaterialToolInformationServiceImpl implements MaterialToolInformationService {

	
	@Autowired
	private MaterialToolInformationMapper materialToolInformationMapper;
	@Override
	public void addMaterialTool(MaterialToolInformation record) {
		// TODO Auto-generated method stub	
		materialToolInformationMapper.insertSelective(record);
	}

	@Override
	public void updateMaterialTool(MaterialToolInformation record) {
		// TODO Auto-generated method stub
		materialToolInformationMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<MaterialToolInformation> selectMaterialTool(String materialClass) {
		// TODO Auto-generated method stub
		return materialToolInformationMapper.selectByMaterialClass(materialClass);
	}

	@Override
	public void deleteMaterialTool(Integer materialId) {
		// TODO Auto-generated method stub
		materialToolInformationMapper.deleteByPrimaryKey(materialId);
		
	}

	@Override
	public List<MaterialToolInformation> selectAllWithQue() {
		// TODO Auto-generated method stub
		System.out.println(materialToolInformationMapper.selectWithQue());
		
		return materialToolInformationMapper.selectWithQue();
	}

	@Override
	public List<MaterialToolInformation> selectMtByMtname(String mtname) {
		// TODO Auto-generated method stub

		return materialToolInformationMapper.selectmtByname(mtname);
	}

	
	
	
	
}
