
package com.ttorder.crud.service;

import java.util.List;

import com.ttorder.crud.bean.FreeInformation;

/** 
* @author 	yushuang
* @version 	2019年8月30日  下午2:00:42 
*  
*/

public interface FreeInformationService {

	void addfree(FreeInformation freeInfo);
	
	void deletefree(Integer id);
	
	void updatefree(FreeInformation freeInfo);
	
	List<FreeInformation> selectfree();
	
	

}
