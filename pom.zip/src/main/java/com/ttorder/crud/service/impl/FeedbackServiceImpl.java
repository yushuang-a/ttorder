
package com.ttorder.crud.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.FeedbackInformation;
import com.ttorder.crud.dao.EmployeeInformationMapper;
import com.ttorder.crud.dao.FeedbackInformationMapper;
import com.ttorder.crud.service.FeedbackService;
import com.ttorder.crud.utils.AllUtils;

/** 
* @author 	yushuang
* @version 	2019年9月19日  上午11:29:28 
*  
*/
@Service
public class FeedbackServiceImpl implements FeedbackService {

	@Autowired
	private EmployeeInformationMapper employeeInformationMapper;
	@Autowired
	private FeedbackInformationMapper feedbackInformationMapper;
	@Override
	public void creatFeed(FeedbackInformation info) {
		
		feedbackInformationMapper.insertSelective(info);
	}

	@Override
	public void outFeed(Integer id) {
	
		feedbackInformationMapper.deleteByPrimaryKey(id);
		
	}

	@Override
	public List<FeedbackInformation> searchFeed(String orderNo) {
	
		List<FeedbackInformation> list = feedbackInformationMapper.getAllFeed(orderNo);
		for (FeedbackInformation feedbackInformation : list) {
			feedbackInformation.setEmpId(employeeInformationMapper.selectNameByempId(AllUtils.toIneger(feedbackInformation.getEmpId())));
		}
		return list;
	}

}
