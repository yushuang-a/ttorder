
package com.ttorder.crud.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.ttorder.crud.bean.ConstructionInformation;

/** 
* @author 	yushuang
* @version 	2019��7��24��  ����5:03:21 
*  
*/
public interface ConstructionInformationService {

	void addConstructionOrder(ConstructionInformation constructionInformation);
	
	List<ConstructionInformation> selectByOrderNo(String orderNo,String constructionType);
}
