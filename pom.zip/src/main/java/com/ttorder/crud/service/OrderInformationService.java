
package com.ttorder.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.OrderInformation;
import com.ttorder.crud.dao.OrderInformationMapper;

/** 
* @author 	yushuang
* @version 	2019��7��23��  ����3:23:49 
*  
*/
public interface OrderInformationService {
	
	
	
	
	public void addAll(OrderInformation record);//增加
	
	public void delete();
	
	public void update();
	
	//根据状态码查询订单信息
	public List<OrderInformation> selectAll(Integer orderStatus);
	
	//根据订单号修改状态码
	public void updateOrderStats(String orderNo,Integer orderStatus);

	//根据员工部门 查询有关员工的订单（待办）
	public List<OrderInformation> selectAllByemp(Integer empId, Integer departmentType);
	
	//根据订单号查询订单基础信息
	public OrderInformation selectOrder(String orderNo);
	
	public boolean selectOrderIsEM(String orderNo);

	public void addInstallerToOrder(String orderNo, Integer empId);

	public List<OrderInformation> selectAllOrder();
	
	//模糊搜索订单列表
	public List<OrderInformation> selectAllInfo(String str,String value);

	public void updateremarksByorderNo(String orderNo, String newremakes);

	public OrderInformation getOrder(Integer orderId);
	
}
