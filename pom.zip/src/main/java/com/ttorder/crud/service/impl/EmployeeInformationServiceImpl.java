
package com.ttorder.crud.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.EmployeeInformation;
import com.ttorder.crud.dao.EmployeeInformationMapper;
import com.ttorder.crud.service.EmployeeInformationService;
import com.ttorder.crud.utils.AllUtils;

/** 
* @author 	yushuang
* @version 	2019年7月25日  下午4:19:08 
*  
*/
@Service
public class EmployeeInformationServiceImpl implements EmployeeInformationService{

	
	@Autowired
	private EmployeeInformationMapper employeeInformationMapper;
	
	@Override
	public void addEmp(EmployeeInformation employeeInformation) {
		// TODO Auto-generated method stub
		employeeInformationMapper.insert(employeeInformation);
	}

	@Override
	public void updateEmp(EmployeeInformation employeeInformation) {
		// TODO Auto-generated method stub
		employeeInformationMapper.updateByPrimaryKeySelective(employeeInformation);
		
	}

	@Override
	public void deleteEmp(Integer employeeId) {
		// TODO Auto-generated method stub
		employeeInformationMapper.deleteByPrimaryKey(employeeId);
	}

	@Override
	public List<EmployeeInformation> selectEmp() {
		// TODO Auto-generated method stub
		
		
		return employeeInformationMapper.selectAllEmp();
	}

	@Override
	public List<EmployeeInformation> searchEmp(String employeeClass) {
		// TODO Auto-generated method stub
		return employeeInformationMapper.searchEmpByemployeeClass(employeeClass);
	}

	@Override
	public List<EmployeeInformation> selectAllInfo(String str, String value) {
		// TODO Auto-generated method stub
		return employeeInformationMapper.searchEmpByType(str,value);
	}

	@Override
	public EmployeeInformation selectEmpById(Integer empId) {
		System.out.println(empId);
		// TODO Auto-generated method stub
		return employeeInformationMapper.selectByPrimaryKey(empId);
	}

}
