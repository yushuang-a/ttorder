
package com.ttorder.crud.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.ImgInformation;
import com.ttorder.crud.dao.ImgInformationMapper;
import com.ttorder.crud.service.ImgService;

/** 
* @author 	yushuang
* @version 	2019年8月24日  下午4:47:21 
*  
*/
@Service
public class ImgServiceImpl implements ImgService {

	
	@Autowired
	private ImgInformationMapper imgInformationMapper;
	@Override
	public void addImg(ImgInformation imgInformation) {
		// TODO Auto-generated method stub
		
		
		imgInformationMapper.insertSelective(imgInformation);
		
	}
	
	@Override
	public List<ImgInformation> getAllImg(String idcode) {
		// TODO Auto-generated method stub
		return imgInformationMapper.selectByIdcode(idcode);
	}

}
