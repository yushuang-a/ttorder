
package com.ttorder.crud.service;

import com.ttorder.crud.bean.EmployeeInformation;

/** 
* @author 	yushuang
* @version 	2019年8月2日  上午10:34:49 
*  
*/

public interface ActionService {

	
	String login(String telephone);
	
	EmployeeInformation loginInfo(String telephone);
	
}
