
package com.ttorder.crud.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.ConstructionInformation;
import com.ttorder.crud.bean.OrderInformation;
import com.ttorder.crud.dao.CellInformationMapper;
import com.ttorder.crud.dao.ConstructionInformationMapper;
import com.ttorder.crud.dao.EmployeeInformationMapper;
import com.ttorder.crud.dao.SupplierInformationMapper;
import com.ttorder.crud.service.ConstructionInformationService;

/** 
* @author 	yushuang
* @version 	2019��7��24��  ����5:04:00 
* 
*/
@Service
public class ConstructionInformationServiceImpl implements ConstructionInformationService{

	
	@Autowired
	private ConstructionInformationMapper constructionInformationMapper;
	@Autowired
	private SupplierInformationMapper supplierInformationMapper;
	@Autowired
	private EmployeeInformationMapper employeeInformationMapper;
	@Autowired
	private CellInformationMapper cellInformationMapper;
	
	public void addConstructionOrder(ConstructionInformation constructionInformation) {
		constructionInformationMapper.insert(constructionInformation);
		
	} 

	@Override
	public List<ConstructionInformation> selectByOrderNo(String orderNo, String constructionType) {
		
		//物业id  物业联系人id 开发商id 开发商联系人 id  小区 id
		List<ConstructionInformation> list = constructionInformationMapper.selectByOrderNO(orderNo, constructionType);
		for (ConstructionInformation constructionInformation : list) {
			if(!constructionInformation.getPropertyId().equals(null)) {
				constructionInformation.setPropertyId(supplierInformationMapper.selectNameById(toIneger(constructionInformation.getPropertyId())));
			}
			if(!constructionInformation.getPropertyContactId().equals(null)) {
				constructionInformation.setPropertyContactId(employeeInformationMapper.selectNameByempId(toIneger(constructionInformation.getPropertyContactId())));
			}
			if(!constructionInformation.getDeveloperId().equals(null)) {
				constructionInformation.setDeveloperId(supplierInformationMapper.selectNameById(toIneger(constructionInformation.getDeveloperId())));
			}
			if(!constructionInformation.getDeveloperPerson().equals(null)) {
				constructionInformation.setDeveloperPerson(employeeInformationMapper.selectNameByempId(toIneger(constructionInformation.getDeveloperPerson())));
			}
			if(!constructionInformation.getCellId().equals(null)) {
				constructionInformation.setCellId(cellInformationMapper.getCellName(toIneger(constructionInformation.getCellId())));
			}
		}
		return list;
	}

	public static Integer toIneger(String str) {
		return Integer.valueOf(str);
	}
	
}
