
package com.ttorder.crud.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.QuotationInformation;
import com.ttorder.crud.dao.QuotationInformationMapper;
import com.ttorder.crud.service.QuotationInformationService;

import java.util.List;

/** 
* @author 	yushuang
* @version 	2019��7��24��  ����5:23:33 
*  
*/
@Service
public class QuotationInformationServiceImpl implements QuotationInformationService{

	
	@Autowired
	private QuotationInformationMapper quotationInformationMapper;
	
	public void addQuotation(QuotationInformation quotationInformation) {
		quotationInformationMapper.insertSelective(quotationInformation);
	}

	public void deleteQuotation(Integer quotationSheetId) {
		quotationInformationMapper.deleteByPrimaryKey(quotationSheetId);
	}

	public List<QuotationInformation> seleteAllquotation(String materialScienceId) {
		return quotationInformationMapper.selectAllBymtId(materialScienceId);
	}


}
