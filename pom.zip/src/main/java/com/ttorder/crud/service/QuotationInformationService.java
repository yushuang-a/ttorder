
package com.ttorder.crud.service;

import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.QuotationInformation;

import java.util.List;

/** 
* @author 	yushuang
* @version 	2019��7��24��  ����5:20:16 
*  
*/
public interface QuotationInformationService {

	void addQuotation(QuotationInformation quotationInformation);

	void deleteQuotation(Integer quotationSheetId);

	List<QuotationInformation> seleteAllquotation(String materialScienceId);
	
}
