
package com.ttorder.crud.service;

import java.util.List;

import com.ttorder.crud.bean.FeedbackInformation;

/** 
* @author 	yushuang
* @version 	2019年9月19日  上午11:18:28 
*  
*/

public interface FeedbackService {

	void creatFeed(FeedbackInformation info);

	void outFeed(Integer id);

	List<FeedbackInformation> searchFeed(String orderNo);

}
