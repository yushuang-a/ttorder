
package com.ttorder.crud.service;

import java.util.List;

import com.ttorder.crud.bean.SupplierInformation;

/** 
* @author 	yushuang
* @version 	2019年7月25日  下午3:18:01 
*  
*/

public interface SupplierInformationService {

	void addCompany(SupplierInformation supplierInformation);
	
	void deleteCompany(Integer supplierId);
	
	void updateCompany(SupplierInformation supplier);
	
	List<SupplierInformation> selectCompany();

	List<SupplierInformation> searchBytype(String businessClass);

	SupplierInformation getSupp(Integer ineger); 
	
}
