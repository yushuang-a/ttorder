
package com.ttorder.crud.service;

import java.util.List;

import com.ttorder.crud.bean.MaterialToolInformation;

/** 
* @author 	yushuang
* @version 	2019年8月5日  下午3:22:28 
*  
*/

public interface MaterialToolInformationService {

	void addMaterialTool(MaterialToolInformation materialToolInfor);
	
	void updateMaterialTool(MaterialToolInformation record);
	
	List<MaterialToolInformation> selectMaterialTool(String materialClass);
	
	void deleteMaterialTool(Integer materialId);
	
	List<MaterialToolInformation> selectAllWithQue();
	
	List<MaterialToolInformation> selectMtByMtname(String mtname);
}
