
package com.ttorder.crud.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.ReturnsurFaceInformation;
import com.ttorder.crud.dao.ReturnsurFaceInformationMapper;
import com.ttorder.crud.service.ReturnsurFaceInformationService;

/** 
* @author 	yushuang
* @version 	2019��7��24��  ����5:49:01 
*  
*/
@Service
public class ReturnsurFaceInformationServiceImpl implements ReturnsurFaceInformationService{

	@Autowired
	private ReturnsurFaceInformationMapper returnsurFaceInformationMapper;
	
	public void addReturnsurFaceInformation(ReturnsurFaceInformation returnsurFaceInformation) {
		// TODO Auto-generated method stub
		
		returnsurFaceInformationMapper.insert(returnsurFaceInformation);
	}

	@Override
	public List<ReturnsurFaceInformation> selectReturnByOrderNo(String orderNo) {
		// TODO Auto-generated method stub
		
		
		return returnsurFaceInformationMapper.selectByOrderNo(orderNo);
	}

	
	
}
