
package com.ttorder.crud.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.SupplierInformation;
import com.ttorder.crud.dao.SupplierInformationMapper;
import com.ttorder.crud.service.SupplierInformationService;

/** 
* @author 	yushuang
* @version 	2019年7月25日  下午3:20:23 
*  
*/
@Service
public class SupplierInformationServiceImpl implements SupplierInformationService{

	
	
	@Autowired
	private SupplierInformationMapper supplierInformationMapper;
	
	@Override
	public void addCompany(SupplierInformation supplierInformation) {
		// TODO Auto-generated method stub
		
		supplierInformationMapper.insert(supplierInformation);
		
	}

	@Override
	public void deleteCompany(Integer supplierId) {
		// TODO Auto-generated method stub
		supplierInformationMapper.deleteByPrimaryKey(supplierId);
	}

	@Override
	public void updateCompany(SupplierInformation supplier) {
		// TODO Auto-generated method stub
		supplierInformationMapper.updateByPrimaryKeySelective(supplier);
		
		
	}

	@Override
	public List<SupplierInformation> selectCompany() {
		// TODO Auto-generated method stub
		
		List<SupplierInformation> list = supplierInformationMapper.selectAllSup();
		
		return list;
	}

	@Override
	public List<SupplierInformation> searchBytype(String businessClass) {
		// TODO Auto-generated method stub
		return supplierInformationMapper.searchDisByClass(businessClass);
	}

	@Override
	public SupplierInformation getSupp(Integer ineger) {
		// TODO Auto-generated method stub
		return supplierInformationMapper.selectByPrimaryKey(ineger);
	}

}
