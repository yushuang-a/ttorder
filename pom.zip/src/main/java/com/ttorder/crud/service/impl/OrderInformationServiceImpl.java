
package com.ttorder.crud.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttorder.crud.bean.OrderInformation;
import com.ttorder.crud.dao.EmployeeInformationMapper;
import com.ttorder.crud.dao.OrderInformationMapper;
import com.ttorder.crud.dao.SupplierInformationMapper;
import com.ttorder.crud.service.OrderInformationService;

/** 
* @author 	yushuang
* @version 	2019��7��24��  ����9:34:03 
*  
*/
@Service
public class OrderInformationServiceImpl implements OrderInformationService{
	
	
	@Autowired
	private OrderInformationMapper orderInformationMapper;
	@Autowired
	private EmployeeInformationMapper employeeInformationMapper;
	@Autowired
	private SupplierInformationMapper supplierInformationMapper;
	
	
	public void addAll(OrderInformation record) {
		
		orderInformationMapper.insertSelective(record);
		
	}

	public void delete() {

		
	}

	public void update() {

		
	}

	public List<OrderInformation> selectAll(Integer orderStatus) {
		
		
		List<OrderInformation> list = orderInformationMapper.selectByOrderStatus(orderStatus);
		for (OrderInformation orderInformation : list) {
			
			if(!orderInformation.getRevisitors().equals(null)) {
			orderInformation.setRevisitors(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getRevisitors())));
			}
			if(!orderInformation.getCustomerServiceName().equals(null)) {
				orderInformation.setCustomerServiceName(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getCustomerServiceName())));
			}
			if(!orderInformation.getSurveyor().equals(null)) {
				orderInformation.setSurveyor(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getSurveyor())));
			}
			if(!orderInformation.getDistributorContactsName().equals(null)) {
				orderInformation.setDistributorContactsName(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getDistributorContactsName())));
			}
			if(!orderInformation.getInstaller().equals(null)) {
				orderInformation.setInstaller(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getInstaller())));
			}
			if(!orderInformation.getDistributorName().equals(null)) {
				orderInformation.setDistributorName(supplierInformationMapper.selectNameById(toIneger(orderInformation.getDistributorName())));	
			}
				
		}

		return list;
		
	}

	@Override
	public void updateOrderStats(String orderNo,Integer orderStatus) {

		orderInformationMapper.updateOrderStatsByOrderNo(orderNo,orderStatus);
	}

	@Override
	public List<OrderInformation> selectAllByemp(Integer empId, Integer departmentType) {

		List<OrderInformation> list = orderInformationMapper.selectByemp(empId, departmentType);
		for (OrderInformation orderInformation : list) {
			if(!orderInformation.getRevisitors().equals(null)) {
				orderInformation.setRevisitors(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getRevisitors())));
				}
				if(!orderInformation.getCustomerServiceName().equals(null)) {
					orderInformation.setCustomerServiceName(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getCustomerServiceName())));
				}
				if(!orderInformation.getSurveyor().equals(null)) {
					orderInformation.setSurveyor(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getSurveyor())));
				}
				if(!orderInformation.getDistributorContactsName().equals(null)) {
					orderInformation.setDistributorContactsName(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getDistributorContactsName())));
				}
				if(!orderInformation.getInstaller().equals(null)) {
					orderInformation.setInstaller(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getInstaller())));
				}
				if(!orderInformation.getDistributorName().equals(null)) {
					orderInformation.setDistributorName(supplierInformationMapper.selectNameById(toIneger(orderInformation.getDistributorName())));	
				}
					
			
			}
		
		return list;
	}

	@Override
	public OrderInformation selectOrder(String orderNo) {
		
		return orderInformationMapper.selectByorderNo(orderNo);
	}

	@Override
	public boolean selectOrderIsEM(String orderNo) {

		return orderInformationMapper.selectByorderNoIsEM(orderNo);
	}

	@Override
	public void addInstallerToOrder(String orderNo, Integer empId) {
		orderInformationMapper.updateInstaller(orderNo, empId);
		
	}

	@Override
	public List<OrderInformation> selectAllOrder() {
		
		List<OrderInformation> list = orderInformationMapper.selectAllOrderWithNull();
		for (OrderInformation orderInformation : list) {
			if(!orderInformation.getRevisitors().equals(null)) {
				orderInformation.setRevisitors(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getRevisitors())));
				}
				if(!orderInformation.getCustomerServiceName().equals(null)) {
					orderInformation.setCustomerServiceName(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getCustomerServiceName())));
				}
				if(!orderInformation.getSurveyor().equals(null)) {
					orderInformation.setSurveyor(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getSurveyor())));
				}
				if(!orderInformation.getDistributorContactsName().equals(null)) {
					orderInformation.setDistributorContactsName(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getDistributorContactsName())));
				}
				if(!orderInformation.getInstaller().equals(null)) {
					orderInformation.setInstaller(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getInstaller())));
				}
				if(!orderInformation.getDistributorName().equals(null)) {
					orderInformation.setDistributorName(supplierInformationMapper.selectNameById(toIneger(orderInformation.getDistributorName())));	
				}
					
		}
		return list;
	}

	@Override
	public List<OrderInformation> selectAllInfo(String str,String value) {

		List<OrderInformation> list = orderInformationMapper.selectOrderWithLike(str, value);
		for (OrderInformation orderInformation : list) {
			
			if(!orderInformation.getRevisitors().equals(null)) {
				orderInformation.setRevisitors(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getRevisitors())));
				}
				if(!orderInformation.getCustomerServiceName().equals(null)) {
					orderInformation.setCustomerServiceName(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getCustomerServiceName())));
				}
				if(!orderInformation.getSurveyor().equals(null)) {
					orderInformation.setSurveyor(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getSurveyor())));
				}
				if(!orderInformation.getDistributorContactsName().equals(null)) {
					orderInformation.setDistributorContactsName(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getDistributorContactsName())));
				}
				if(!orderInformation.getInstaller().equals(null)) {
					orderInformation.setInstaller(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getInstaller())));
				}
				if(!orderInformation.getDistributorName().equals(null)) {
					orderInformation.setDistributorName(supplierInformationMapper.selectNameById(toIneger(orderInformation.getDistributorName())));	
				}
					
		}
		return list;
	}

	public static Integer toIneger(String str) {
		return Integer.valueOf(str);
	}

	@Override
	public void updateremarksByorderNo(String orderNo, String newremakes) {
		
		orderInformationMapper.updateremarksToNew(orderNo,newremakes);
		
	}

	@Override
	public OrderInformation getOrder(Integer orderId) {
		
		OrderInformation orderInformation = orderInformationMapper.selectByPrimaryKey(orderId);
//		if(!orderInformation.getRevisitors().equals(null)) {
//			orderInformation.setRevisitors(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getRevisitors())));
//			}
//			if(!orderInformation.getCustomerServiceName().equals(null)) {
//				orderInformation.setCustomerServiceName(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getCustomerServiceName())));
//			}
//			if(!orderInformation.getSurveyor().equals(null)) {
//				orderInformation.setSurveyor(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getSurveyor())));
//			}
//			if(!orderInformation.getDistributorContactsName().equals(null)) {
//				orderInformation.setDistributorContactsName(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getDistributorContactsName())));
//			}
//			if(!orderInformation.getInstaller().equals(null)) {
//				orderInformation.setInstaller(employeeInformationMapper.selectNameByempId(toIneger(orderInformation.getInstaller())));
//			}
//			if(!orderInformation.getDistributorName().equals(null)) {
//				orderInformation.setDistributorName(supplierInformationMapper.selectNameById(toIneger(orderInformation.getDistributorName())));	
//			}
		
		
		// TODO Auto-generated method stub
		return orderInformation;
	}
	
	
}
